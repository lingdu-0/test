package test_019.test_019;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class EditActivity extends AppCompatActivity {

    TextView txv;
    EditText edt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent it = getIntent();//获取传入的Intent对象
        String s = it.getStringExtra("备忘");//读出名为"备忘"的String数据（而不用再读取编号数据）
        txv = (TextView) findViewById(R.id.textView);//将txv改在第2行声明
        txv.setText(s.substring(0, 2));                 //将编号显示在画面左上角
        edt = (EditText) findViewById(R.id.editText);
        if (s.length() > 2)
            edt.setText(s.substring(2));

        /*Intent it = getIntent();            //获取传入的Intent对象
        int no = it.getIntExtra("编号",0);//读出名为"编号"的Int数据，若没有则返回 0
        String s = it.getStringExtra("备忘");         //读出名为"备忘"的String数据
        String ds = it.getStringExtra("日期");

        TextView txv =(TextView) findViewById(R.id.textView);
        txv.setText(no+".");            //在画面左上角显示编号
        EditText edt = (EditText) findViewById(R.id.editText);
        if (s.length()>2)
            edt.setText(s.substring(2)+"\n"+ds);
            //将传来的备忘数据去除前3个字符，然后填入EditText组件中
*/
    }
    public void onCancel(View v) {//单击取消按钮时
        setResult(RESULT_CANCELED);
        finish();                   //结束activity
    }
    public void onSave(View v) {//单击存储按钮时
        Intent it2 = new Intent();
        it2.putExtra("备忘",txv.getText()+" "+edt.getText());
        setResult(RESULT_OK,it2);
        finish();               //结束activity
    }
}
