package test_019.test_019;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,AdapterView.OnItemLongClickListener{

    String[] aMemo = {//默认的备忘内容
            "1.单击可以编辑备忘",
            "2.长按可以清除备忘","3.","4.","5.","6."};
    ListView lv;                //显示备忘录的 ListView
    ArrayAdapter<String> aa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv =(ListView) findViewById(R.id.listView);
        aa = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,aMemo);
        lv.setAdapter(aa);//设置listView1的内容
        //设置listView被单击的监听器
        lv.setOnItemClickListener(this);
        //设置listView被长按的监听器
        lv.setOnItemLongClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> a, View v, int pos, long id) {
        Intent it = new Intent(this, EditActivity.class);
        it.putExtra("备忘",aMemo[pos]);//只附加备忘选项的内容（不用附加编号）
        startActivityForResult(it,pos);         //启动EditActivity 并以选项位置为标识符
      /*  it.putExtra("编号",pos+1);
        it.putExtra("备忘",aMemo[pos]);
        it.putExtra("日期",new Date().toString());//获取日期时间
        startActivity(it);*/
    }

    protected void onActivityResult(int requestCode,int resultCode,Intent it) {
        if (requestCode == RESULT_OK) {
            aMemo[requestCode] = it.getStringExtra("备忘");//使用返回的数据更新数组内容
            aa.notifyDataSetChanged();                              //通知Adapter数组内容有更新
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> a, View v, int pos, long id) {
        aMemo[pos] = (pos+1) +".";//将内容清除（只剩编号）
        aa.notifyDataSetChanged(); //通知ListView要更新显示的内容
        return true;                //  返回true 表示此事件已处理
    }
}
