package test_024.test_024;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    static final int MIN_TIME = 5000;//位置更新条件：5000毫秒（=5秒）
    static final int MIN_DIST = 5;//位置更新条件：5米
    LocationManager mgr;        //定位管理器
    TextView txv;
    Location myLocation;//存储最近的定位数据
    Geocoder geocoder;//用来查询地址的Geocoder对象
    EditText edtLat,edtLon;//经纬度输入字段

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txv = (TextView) findViewById(R.id.txv);
        mgr = (LocationManager) getSystemService(LOCATION_SERVICE);//获取系统服务的LocationManager对象
        edtLat =(EditText) findViewById(R.id.edtLan);
        edtLon =(EditText) findViewById(R.id.edtLon);
        geocoder =new Geocoder(this, Locale.getDefault());//创建Geocoder对象
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onResume() {
        super.onResume();
        //获取最佳的定位提供者
        String best = mgr.getBestProvider(new Criteria(), true);//找出已启用的提供者
        if (best != null) {//如果有定位提供者可用
            txv.setText("当前位置信息获取中...");
            mgr.requestLocationUpdates(best, MIN_TIME, MIN_DIST, this);//注册位置事件监听器
        }else //无提供者，显示提示信息
        txv.setText("请确认已开启定位功能！");
    }
    @Override
    protected void onPause() {
        super.onPause();
        mgr.removeUpdates(this);//取消注册监听事件
    }

    @Override
    public void onLocationChanged(Location location) {//位置变更事件
        myLocation = location;//存储定位数据
        String str = "定位提供者："+location.getProvider();
        str+=String.format("\n纬度：%.5f\n经度：%.5f\n高度：%.2f米",
                location.getLatitude(),//纬度
                location.getLongitude(),//经度
                location.getAltitude());//高度
                txv.setText(str);
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
    public void setup(View v) {
        Intent it = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);//设置Intent对象启动定位设置程序
        startActivity(it);
    }

    public void getLocation(View v) {//"以手机位置当输入"按钮的OnClick事件
        if (myLocation != null) {//若位置对象非null
            edtLat.setText(Double.toString(myLocation.getLatitude()));//将经度值转换成字符串
            edtLon.setText(Double.toString(myLocation.getLongitude()));//将纬度值转成字符串
        }else
            txv.setText("无法获取定位数据！");
    }

    public void onQuery(View v) {//"用经纬度查询地址"按钮的OnClick事件
        String strLat =edtLat.getText().toString();//获取输入的纬度字符串
        String staLon =edtLon.getText().toString();//获取输入的经度字符串
        if (strLat.length()==0||staLon.length()==0)//当字符串为空时
            return;//结束处理
        txv.setText("读取中...");
        double latitude =Double.parseDouble(strLat);//获取纬度值
        double longitude =Double.parseDouble(staLon);//获取经度值
        String strAddr = "";//用来创建所要显示的信息字符串（地址字符串）
        try{
            List<Address> listAddr = geocoder.getFromLocation(latitude,longitude,1);
            if (listAddr==null||listAddr.size()==0)
                strAddr+="无法获取地址数据！";
            else {
                Address addr = listAddr.get(0);
                for (int i =0; i<=addr.getMaxAddressLineIndex();i++)
                    strAddr+=addr.getAddressLine(i)+"\n";
            }
        }catch (Exception ex){
            strAddr +="获取地址发生错误："+ex.toString();
        }
        txv.setText(strAddr);

    }
}
