package test_016.test_016;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements DialogInterface.OnClickListener{//实现监听接口

    TextView txv;     //记录默认的Text View组件
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txv = (TextView)findViewById(R.id.answer);          //找出预设的TextView

        new AlertDialog.Builder(this)           //创建Builder对象
                .setMessage("你喜欢安卓手机吗？")        //设置显示信息
                .setCancelable(false)                   //禁用返回关闭键关闭对话框
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Android 问卷调查")
                .setPositiveButton("喜欢",this)
                .setNegativeButton("讨厌",this)
                .setNeutralButton("没意见",this)
                .show();
    }

    @Override
    public void onClick(DialogInterface dialog, int i) {//实现监听接口定义的方法
        if (i == DialogInterface.BUTTON_POSITIVE) {//如果单击肯定的“喜欢”
            txv.setText("你喜欢Android手机");
        } else if (i == DialogInterface.BUTTON_NEGATIVE) {//如果单机否定的“讨厌”
            txv.setText("你讨厌Android手机");
        } else {
            txv.setText("要不要试用看看Android手机呢？");
        }
    }
}
