package w.cn.fragment;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
        Button btn1,btn2,btn3;
        btn1=(Button) findViewById(R.id.btn1);
        btn2=(Button) findViewById(R.id.btn2);
        btn3=(Button) findViewById(R.id.btn3);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 创建一个要放入 Activity 布局中的新 Fragment
                BlankFragment f = new BlankFragment();
                FragmentManager fm=getSupportFragmentManager();
                //事物
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.main_layout,f);
                ft.commit();

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 创建一个要放入 Activity 布局中的新 Fragment
                TowFragment f = new TowFragment();
                FragmentManager fm=getSupportFragmentManager();
                //事物
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.main_layout,f);
                ft.commit();
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanFragment f=new SanFragment();
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.main_layout,f);
                ft.commit();
            }
        });
    }
}
