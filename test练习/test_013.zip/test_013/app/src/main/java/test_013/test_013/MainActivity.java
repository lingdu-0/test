package test_013.test_013;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txv;
    Spinner cinema,time;//显示影院列表的Spinner 对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txv = (TextView)findViewById(R.id.txv);//获取TextView 对象
        cinema = (Spinner)findViewById(R.id.cinema);//获取Spinner对象
        time =(Spinner)findViewById(R.id.time);
    }
    public void order(View v) {
        String[] cinemas=getResources().getStringArray(R.array.cinemas);//获取字符串资源中的字符数组
        String[] times=getResources().getStringArray(R.array.times);
                                                                        //获取Spinner
        int index1=time.getSelectedItemPosition();
        int index=cinema.getSelectedItemPosition();//被选取选项的位置
        txv.setText("订"+cinemas[index]+times[index1]+"的票");
    }
}
