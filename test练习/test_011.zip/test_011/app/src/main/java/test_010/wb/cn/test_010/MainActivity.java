package test_010.wb.cn.test_010;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] chk_id = {R.id.chk1,R.id.chk2,R.id.chk3,R.id.chk4,R.id.chk5,R.id.chk6,R.id.chk7,R.id.chk8};
        for (int id:chk_id) //为每个CheckBox注册监听对象
            ((CheckBox) findViewById(id)).setOnCheckedChangeListener(this);
    }
    int items=0;//记录当前选取餐点数量
    @Override
    public void onCheckedChanged(CompoundButton chk,boolean isChecked) {
        int visible;        //  CheckBox显示状态
        if (isChecked) {    //被选取时
            items++;        //数量加1
            visible = View.VISIBLE;
            //应使用的visiblelity属性值为VISIBLE(可见)
        } else {            //被取消时
            items--;           //数量减一
            visible=View.GONE;
            //应使用的visiblelity属性值为GONE(不可见)
        }
        switch (chk.getId()) {//按选取选项的资源ID，决定要更改的ImageView
            case R.id.chk1:
                findViewById(R.id.output9).setVisibility(visible);
                break;
            case R.id.chk2:
                findViewById(R.id.output10).setVisibility(visible);
                break;
            case R.id.chk3:
                findViewById(R.id.output11).setVisibility(visible);
                break;
            case R.id.chk4:
                findViewById(R.id.output12).setVisibility(visible);
                break;
            case R.id.chk5:
                findViewById(R.id.output13).setVisibility(visible);
                break;
            case R.id.chk6:
                findViewById(R.id.output14).setVisibility(visible);
                break;
            case R.id.chk7:
                findViewById(R.id.output15).setVisibility(visible);
                break;
            case R.id.chk8:
                findViewById(R.id.output16).setVisibility(visible);
                break;
        }
        String msg;
        if(items>0)//选项大于0，显示有点餐的信息
            msg="你点的餐点如下：";
        else                //否则显示请点餐的信息
            msg="请点餐！";
        ((TextView)findViewById(R.id.showOrder)).setText(msg);
    }
}


