package test_021.test_021;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Uri imgUri;         //拍照时存盘的Uri对象
    ImageView imv;         //ImageView对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);//设置屏幕不随手机旋转
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//设置屏幕直向显示
        imv = (ImageView) findViewById(R.id.imageView);

    }
    public void onGet(View v) {     //单击拍照按钮时执行的方法
        //获取系统的公用图像文件路径
        Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
       String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
        String fname = "p" + System.currentTimeMillis() + ".jpg";       //利用当前时间组合出一个不会重名的文件名
        imgUri = Uri.parse("file://"+ dir + "/" + fname);               //按前面的路径和文件名创建Uri对象
        it.putExtra(MediaStore.EXTRA_OUTPUT,imgUri);            //将uri加到拍照Intent 的额外数据中
        startActivityForResult(it,100);                //启动Intent
        /*Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);//创建动作为拍照的Intent
        startActivityForResult(it,100);         //启动Intent并要求返回数据*/

    }
    public void onPick(View v) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);//动作设为“选取内容”
        it.setType("image/*");                          //设置选取的媒体类型为“所有类型的图片”
        startActivityForResult(it,101);     //启动Intent,并要求返回选取的图像文件

    }
    protected  void onActivityResult (int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode == Activity.RESULT_OK){//要求的intent成功了
            switch (requestCode){
                case 100://拍照
                    Intent it = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,imgUri);//设置为系统共享媒体文件
                    sendBroadcast(it);
                    break;
                case 101://选取照片
                    imgUri = convertUri(data.getData());//获取选取照片的uri并进行Uri格式转换
                    break;
            }
            showImg();//显示照片
           /* Bitmap bmp = (Bitmap)BitmapFactory.decodeFile(imgUri.getPath());//读取图像文件内容转换为Bitmap对象

           imv.setImageBitmap(bmp);                                //将Bitmap对象显示在ImageView中*/
        }else
            Toast.makeText(this,requestCode==100? "没有拍到照片":"没有选取照片",Toast.LENGTH_LONG).show();

        /*if (resultCode == Activity.RESULT_OK && requestCode ==100){
            Bundle extras = data.getExtras();           //将Intent的附加数据转为Bundle 对象
            Bitmap bmp = (Bitmap) extras.get("data");   //从Bundle 取出名为"data"的Bitmap 数据
            ImageView imv = (ImageView) findViewById(R.id.imageView);
            imv.setImageBitmap(bmp);                    //将Bitma数据显示在ImageView中
        }else{
            Toast.makeText(this,"没有拍到照片",Toast.LENGTH_LONG).show();
        }*/
    }

    private Uri convertUri(Uri uri) {
        if (uri.toString().substring(0,7).equals("content")){//如果是以“content”开头
            String[] colName = {MediaStore.MediaColumns.DATA};//声明要查询的字段
            Cursor cursor =getContentResolver().query(uri,colName,null,null,null);//以uri进行查询
            cursor.moveToFirst();//移动到差查询结果的第一个记录
            uri = Uri.parse("file://"+cursor.getString(0));//将路径转为Uri
            cursor.close();                                     //关闭查询
        }
        return uri;                                             //返回uri
    }


    void showImg() {
        int  iw,ih, vw,vh;
        boolean needRotate;//用来存储是否需要旋转
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imgUri.getPath(),option);
        iw =option.outWidth;
        ih = option.outHeight;
        vw = imv.getWidth();
        vh = imv.getHeight();
        int scaleFactor;
        if (iw<ih){//如果图片的宽度小于高度
            needRotate = false;//不需要旋转
            scaleFactor = Math.min(iw/vw,ih/vh);//计算缩小比例

        }else {
            needRotate = true;//需要旋转
            scaleFactor = Math.min(ih/vw, iw/vh);//改用旋转后的图片宽，高来计算缩小比例
        }
        option.inJustDecodeBounds = false;//关闭只加载图像文件信息的选项
        option.inSampleSize = scaleFactor;//设置缩小比例，例如2 则长宽都将缩小为原来的1/2

        Bitmap bmp = BitmapFactory.decodeFile(imgUri.getPath(),option);//载入图片
        if (needRotate){
            Matrix matrix = new Matrix();
            matrix.postRotate(90);
            bmp =Bitmap.createBitmap(bmp,0,0,bmp.getWidth(),bmp.getHeight(),matrix,true);
        }
        imv.setImageBitmap(bmp);
        new AlertDialog.Builder(this).setTitle("图像文件信息")
                .setMessage("图像文件路径："+imgUri.getPath()+"\n原始尺寸："+iw +"x"+bmp.getHeight() +
                "\n载入尺寸："+ vw + "x"+vh+(needRotate?"(旋转)":""))
                .setNegativeButton("关闭",null).show();
    }
}
