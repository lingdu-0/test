package test_022.test_022;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements      //实现MediaPlayer的3个事件监听接口
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnErrorListener,
        MediaPlayer.OnCompletionListener {
    Uri uri;            //存储影音文件的 Uri
    TextView txvName,txvUri;            //用来引用界面的组件
    boolean isVideo = false;        //记录是否为视频文件（否则为音乐文件）
    Button btnPlay,btnStop;         //用来引用播放按钮和停止按钮
    CheckBox ckbLoop;               //用来引用重复播放多选按钮
    MediaPlayer mper;               //用来引用MediaPlayer
    Toast tos;                      //用来引用Toast对象（用于显示信息）

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //设置屏幕不随手机旋转以及界面直向显示
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);//设置屏幕不随手机旋转
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//设置屏幕直向显示
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//设置屏幕不进入休眠

        txvName =(TextView) findViewById(R.id.txvName);     //获取“文件”文本组件
        txvUri = (TextView)findViewById(R.id.txvUri);       //获取“路径”文本组件
        btnPlay=(Button)findViewById(R.id.btnPlay);         //获取播放按钮
        btnStop = (Button)findViewById(R.id.btnStop);       //获取停止按钮
        ckbLoop = (CheckBox)findViewById(R.id.ckbLoop);     //获取重复播放多选按钮
        uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.welcome);//默认会播放程序内的音乐文件welcome.mp3
        txvName.setText("歌曲："+"welcome.mp3");//在界面中显示文件名
        txvUri.setText("程序内的乐曲："+uri.toString());//显示内建音乐文件的URI路径
        mper = new MediaPlayer();                       //创建MediaPlayer对象
        mper.setOnPreparedListener(this);               //设置3个监听事件
        mper.setOnErrorListener(this);
        mper.setOnCompletionListener(this);
        tos = Toast.makeText(this,"",Toast.LENGTH_SHORT);//创建Toast对象
        prepareMusic();     //准备默认音乐（welcome.mp3）的播放
    }

    public void prepareMusic() {
        btnPlay.setText("播放");//将按钮文字显示为播放
        btnPlay.setEnabled(false);//使播放按钮不能按（要等准备好才能单击）
        btnPlay.setEnabled(false);//使停止按钮不能按
        try{
            mper.reset();           //若之前播放过歌曲，则必须reset后才能换歌
            mper.setDataSource(this,uri);//指定音乐来源
            mper.setLooping(ckbLoop.isChecked());//设置是否重复播放
            mper.prepareAsync();                    //要求MediaPlayer准备播放指定的音乐
            btnPlay.setEnabled(true);

        }catch (Exception e){                   //拦截错误并显示信息
            tos.setText("指定音乐文件错误！"+e.toString());
            tos.show();

        }
    }

    public void onPick(View v) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);//创建动作为“选取内容”的Intent
        if (v.getId() == R.id.btnPickAudio) {//如果是“选取歌曲”按钮
            it.setType("audio/*");              //要选取的音乐类型
            startActivityForResult(it, 100);//以识别编号100 来启动外部程序
        } else {            //否则就是“选取视频”按钮
            it.setType("video/*");//要选取的所有视频类型
            startActivityForResult(it,101);//以识别编号101来启动外部程序
        }
    }
      protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode == Activity.RESULT_OK){//如果选取成功
            isVideo = (requestCode == 101);     //记录是否选取了视频文件（当识别码为101时）
            uri = convertUri(data.getData());      //获取选取文件的Uri并进行Uri格式转换
            txvName.setText(((isVideo)?"视频:":"音乐:")+uri.getLastPathSegment());//显示文件名称（Uri最后一段文字）
            txvUri.setText("文件位置："+uri.getPath());//显示文件路径
            if (!isVideo)
            prepareMusic();//如果是音乐文件就准备播放
        }
      }

    private Uri convertUri(Uri uri) {//将“convertUri”类型的Uri转换为“file：//的Uri”
        if (uri.toString().substring(0,7).equals("content")){//如果是以“content”开头
            String[] colName = {MediaStore.MediaColumns.DATA};  //声明要查询的字段
            Cursor cursor = getContentResolver().query(uri,colName,null,null,null);//以uri进行查询
            cursor.moveToFirst();           //移到查询结果的第一个目录
            uri = Uri.parse("file://"+cursor.getString(0));//将路径转换为Uri
            cursor.close();     //关闭查询结果+
        }
        return uri;//返回uri对象
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        btnPlay.setEnabled(true);//当准备好时，让播放按钮起作用（可以单击）
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        tos.setText("发生错误，停止播放");//当发生错误时，显示错误信息
        tos.show();
        return true;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {//当音乐播放完毕时
        mper.seekTo(0);//将播放位置归 0
        btnPlay.setText("播放");//让播放按钮显示“播放”
        btnStop.setEnabled(false);//让停止按钮禁用（不能单击），因为音乐已经停止播放
    }

    public void onMpPlay(View v) {//按播放按钮时
        if (isVideo){//如果是视频
            Intent it =new Intent(this,Video.class);//创建打开Video Activity的Intent
            it.putExtra("uri",uri.toString());              //将视频的Uri以“uri”为名加入Intent中
            startActivity(it);          //启动Video Activity
            return;         //结束本方法
        }
        if (mper.isPlaying()) {//如果正在播放，就暂停
            mper.pause();//暂停播放
            btnPlay.setText("继续");
        } else {//如果没有在播放，就开始播放
            mper.start();//开始播放
            btnPlay.setText("暂停");//让播放按钮显示“暂停”
            btnStop.setEnabled(true);//音乐已经播放，所以让停止按钮起作用
        }
    }
    public void onMpStop(View v) {
        mper.pause();//暂停播放
        mper.seekTo(0);//移到音乐中0秒的位置
        btnPlay.setText("播放");
        btnStop.setEnabled(false);//让停止按钮不能在按
    }
    public void onMpLoop(View v) {//按下重复播放多选按钮时
        if (ckbLoop.isChecked())
            mper.setLooping(true);//设置要重复播放
        else
            mper.setLooping(false);//设置不要重复播放
    }
    public void onMpBackward(View v) {//按倒退图形按钮时
        if (!btnPlay.isEnabled())return;
        //如果还没准备好（播放按钮不能按），则不处理
        int len = mper.getDuration();//读取音乐长度
        int pos = mper.getCurrentPosition();//读取当前播放位置
        pos -= 10000;//倒退10秒（10000毫秒）
        if (pos<0)pos=0;//不可小于0
        mper.seekTo(pos);//移动播放位置
        tos.setText("倒退10秒："+pos/1000+"/"+len/1000);//显示信息
        tos.show();
    }
    public void onMpForward(View v){//按下快进图形按钮时
        if (!btnPlay.isEnabled())return;//如果还没准备好（播放按钮不能按），则不处理
        int len =mper.getDuration();//读取音乐长度
        int pos = mper.getCurrentPosition();//读取当前播放位置
        pos+=10000;//快进10秒
        if(pos>len)pos=len;//不可大于总秒数
        mper.seekTo(pos);//移动播放位置
        tos.setText("快进10秒："+pos/1000+"/"+len/1000);//显示信息
        tos.show();
    }
    @Override
    protected void onPause() {
        super.onPause();//执行父类的事件方法以处理必要事宜
        if (mper.isPlaying()) {//如果正在播放就暂停
            btnPlay.setText("继续");
            mper.pause();//暂停播放
        }
    }
    protected void onDestory() {
        mper.release();//释放MediaPlayer对象
        super.onDestroy();//执行父类的事件方法以处理必要事宜

    }

}
