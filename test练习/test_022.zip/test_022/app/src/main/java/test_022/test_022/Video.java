package test_022.test_022;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.VideoView;

public class Video extends AppCompatActivity implements MediaPlayer.OnCompletionListener{//实现播放完毕的事件监听接口

    VideoView vdv;
    int pos = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);//隐藏系统状态栏
        getSupportActionBar().hide();//隐藏Activity的标题栏
        setContentView(R.layout.activity_video);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕一直开着不会休眠
        Intent it = getIntent();//获取传入的Intent对象
        Uri uri =Uri.parse(it.getStringExtra("uri"));//获取要播放视频的Uri
        if (savedInstanceState != null) //如果是因为旋转而重新启动Activity
            pos =savedInstanceState.getInt("pos",0);
        vdv = (VideoView)findViewById(R.id.videoView);//获取界面中的videoview组件
        MediaController mediaCtrl = new MediaController(this);//建立播放控制对象
        vdv.setMediaController(mediaCtrl);//设置播放控制对象
        vdv.setVideoURI(uri);//设置播放视频的uri
        vdv.setOnCompletionListener(this);//设置播放完毕时的监听器
    }
    protected  void onResume() {//当Activity启动或由暂停状态回到互动状态时
        super.onResume();
        vdv.seekTo(pos);//移到pos的播放位置
        vdv.start();//开始播放
    }
    protected void onpause(){//当Activity进入暂停状态时
        super.onResume();
        pos = vdv.getCurrentPosition();//存储播放位置
        vdv.stopPlayback();//停止播放
    }
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("pos",pos);//将播放onPause中获取的播放位置存储到bundle中
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {//当播放完毕时
        finish();//结束当前的Activity
    }
}
