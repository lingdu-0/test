package test_010.wb.cn.test_010;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    ArrayList<CompoundButton> selected =new ArrayList<>();

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked)                              //若选项被选取
            selected.add(buttonView);               //加到集合之中
        else                                        //若被选项取消
            selected.remove(buttonView);            //从集合中删除

    }

    public void takeOrder(View v) {
        String msg = "";//存放要显示在画面上的文字信息
        for (CompoundButton chk:selected)
            msg +="\n"+chk.getText();
        if(msg.length()>0)//有点餐
            msg="你点购的餐点是："+msg;
        else
            msg="请点餐！";
        ((TextView) findViewById(R.id.showOrder)).setText(msg);
        /*CheckBox chk;
        String msg = "";//存放要显示在画面上的文字信息
        //用数组存放所有 CheckBox 组件的 ID
        int[] id = {R.id.chk1, R.id.chk2, R.id.chk3, R.id.chk4,R.id.chk5,R.id.chk6,R.id.chk7,R.id.chk8};
        for (int i : id) {//一循环逐一查看各CheckBox是否被选取
            chk = (CheckBox) findViewById(i);
            if (chk.isChecked()) {//若被选取
                msg += "\n" + chk.getText();//将换行字符和选项文字
            }                                  //附加到msg字符串后面
        }
            if (msg.length() > 0)               //有点餐（字符串长度大于0）
                msg = "你点购的餐点是：" + msg;
            else
                msg = "请点餐！";
            //在文本框中显示点购的选项*/

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] chk_id = {R.id.chk1, R.id.chk2, R.id.chk3, R.id.chk4,R.id.chk5,R.id.chk6,R.id.chk7,R.id.chk8};
        for (int id:chk_id) {
            CheckBox chk = (CheckBox) findViewById(id);
            chk.setOnCheckedChangeListener(this);
        }
    }

}
