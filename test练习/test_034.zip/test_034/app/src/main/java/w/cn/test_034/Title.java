package w.cn.test_034;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Title extends AppCompatActivity implements View.OnClickListener{

    private TextView mTitleTextView;
    private Button btnReturn;
    private Button btnSetUp;
    private FrameLayout mContentLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupViews();   //加载 activity_title 布局 ，并获取标题及两侧按钮
        btnReturn.setOnClickListener(this);
    }

    private void setupViews() {
        super.setContentView(R.layout.title);
        mTitleTextView = (TextView) findViewById(R.id.text_title);
       // mContentLayout = (FrameLayout) findViewById(R.id.layout_content);
        btnReturn = (Button) findViewById(R.id.btn_return);
        btnSetUp = (Button) findViewById(R.id.btn_SetUp);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_return:
                finish();
                break;
            case R.id.btn_SetUp:
                Toast.makeText(this,"这是设置！",Toast.LENGTH_SHORT).show();
                break;
        }


    }
}
