package w.cn.test_034;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;

public class Index extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.index);
        /*ActionBar actionBar =getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }*/
        Handler x = new Handler();
        x.postDelayed(new splashhandler(), 2000);//2秒后进入主界面！

    }

    class splashhandler implements Runnable {
        public void run() {
            startActivity(new Intent(getApplication(), MainActivity.class));
            Index.this.finish();
        }
    }
}
