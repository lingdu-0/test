package w.cn.test_034;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Math.sqrt;

public class ToCalculate extends AppCompatActivity {
    int a,b,c,d,e,h,i;
    double f,g;
    Spinner level;
    TextView txv;
    EditText edt1,edt2,edt3,edt4,edt5;

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mian,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.setup:
                Toast.makeText(this,"设置菜单",Toast.LENGTH_SHORT).show();
                break;
            case R.id.exit:
                finish();
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.to_calculate);
        txv=(TextView)findViewById(R.id.txv);//计算结果
        edt1=(EditText)findViewById(R.id.edt1);//起点横坐标
        edt2=(EditText)findViewById(R.id.edt2);//起点纵坐标
        edt3=(EditText)findViewById(R.id.edt3);//终点横坐标
        edt4=(EditText)findViewById(R.id.edt4);//终点纵坐标
        edt5=(EditText)findViewById(R.id.edt5);//行军速度
        level=(Spinner)findViewById(R.id.level);//地形条件
    }
    public void abc(int a, int b, int c, int d, int e, int index, int i, String[] levels) {
        int time1,time2,time3;
        f = sqrt((a - c) * (a - c) + (b - d) * (b - d));
        g = f / e *3600;
        time1= (int) (g/3600);
        time2= (int) ((g/60)%60);
        time3= (int) (g%60);
        h= (int) (i*((f*3+100)/100));
        txv.setText("目的地选择为：" + levels[index] +
                "\n起点：" + a + "；" + b +
                "\n终点：" + c + "；" + d +
                "\n行军距离：" + String.format("%.1f", f) +
                "\n行军时间：" +time1+":"+time2+":"+time3+
                "\n兵力情况："+h);
    }
    public void onClick(View v) {
        int index = level.getSelectedItemPosition();
        String[] levels = getResources().getStringArray(R.array.level);//获取字符串资源中的字符数
        if (edt1.getText().toString().trim().length() > 0&edt2.getText().toString().trim().length() > 0&edt3.getText().toString().trim().length() > 0&edt4.getText().toString().trim().length() > 0&edt5.getText().toString().trim().length() > 0) {
            a = Integer.parseInt(edt1.getText().toString());
            b = Integer.parseInt(edt2.getText().toString());
            c = Integer.parseInt(edt3.getText().toString());
            d = Integer.parseInt(edt4.getText().toString());
            e = Integer.parseInt(edt5.getText().toString());
            switch (index) {
                case 0: {
                    int time1, time2, time3;
                    f = sqrt((a - c) * (a - c) + (b - d) * (b - d));
                    g = f / e * 3600;
                    time1 = (int) (g / 3600);
                    time2 = (int) ((g / 60) % 60);
                    time3 = (int) (g % 60);
                    txv.setText("目的地选择为：" + levels[index] +
                            "\n起点：" + a + "；" + b +
                            "\n终点：" + c + "；" + d +
                            "\n行军距离：" + String.format("%.1f", f) +
                            "\n行军时间：" + time1 + ":" + time2 + ":" + time3);
                    break;
                }
                case 1: {//100兵力
                    int i = 100;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 2: {//600兵力
                    int i = 600;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 3: {//1800兵力
                    int i = 1800;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 4: {//5000兵力
                    int i = 5000;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 5: {//9000兵力
                    int i = 9000;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 6: {//16500*2
                    int i = 16500;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 7: {//21000*2
                    int i = 21000;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 8: {//25500*2
                    int i = 25500;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
                case 9: {//30000*2
                    int i = 30000;
                    abc(a, b, c, d, e, index, i, levels);
                    break;
                }
            }
        }else
            Toast.makeText(this,"请输入全部数值才能计算！",Toast.LENGTH_SHORT).show();
        // txv.setText("请输入全部数值才能计算！");
    }

    public void reset(View view) {
        //重置按钮
        txv.setText("");
        edt1.setText("");
        edt2.setText("");
        edt3.setText("");
        edt4.setText("");
        edt5.setText("");
    }
}

