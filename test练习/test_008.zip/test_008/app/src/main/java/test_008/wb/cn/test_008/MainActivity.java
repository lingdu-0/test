package test_008.wb.cn.test_008;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public void show(View v) {
        TextView txv =(TextView) findViewById(R.id.txv);
        RadioGroup ticketType = (RadioGroup) findViewById(R.id.ticketType);
        RadioGroup ticketType2 = (RadioGroup) findViewById(R.id.ticketType2);
        //按选取的选项显示不同的信息
        int id2 =ticketType2.getCheckedRadioButtonId();
        int id =ticketType.getCheckedRadioButtonId();
        RadioButton select =(RadioButton)findViewById(id);
        RadioButton select2 =(RadioButton)findViewById(id2);
        txv.setText("购买"+select.getText()+select2.getText());//输出选取选项的文字
       /* switch (ticketType.getCheckedRadioButtonId()) {
            case R.id.aduit:
                txv.setText("买全票");
                break;
            case R.id.child:
                txv.setText("买半票");
                break;
            case R.id.senior:
                txv.setText("买敬老票");
                break;
        }*/
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
