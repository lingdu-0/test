package test_015.test_015;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{

    //创建问题
    String[] queArr = {"什么门永远关不上？","什么东西没人爱吃？","什么瓜不能吃？","什么布剪不断？","什么鼠最爱干净？","偷什么不犯法？"};
    String[] ansArr = {"球门","亏","傻瓜","瀑布","环保署","偷笑"};
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //创建供ListView 使用的ArrayAdapter 对象
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,queArr);
        //使用内建布局资源
        //以queArr数组当数据源
        ListView lv = (ListView)findViewById(R.id.lv);//获取ListView
        lv.setAdapter(adapter);//设置ListView使用的Adapter
        lv.setOnItemClickListener(this);//设置ListView选项被单击时的事件监听器
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this,"答案:"+ansArr[position],//从ansArr数组取得答案  
                Toast.LENGTH_SHORT).show();
    }
}
