package test_027.test_027;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ChaJian extends AccessibilityService{
    private String[] filter = new String[]{"A、对"};
    AccessibilityNodeInfo rootnodeInfo=null;
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        rootnodeInfo= event.getSource();
        if (rootnodeInfo == null) {
            return;
        }
        startClick(rootnodeInfo);

    }

    private void startClick(AccessibilityNodeInfo rootnodeInfo) {
        List<AccessibilityNodeInfo> list=findByText(rootnodeInfo);
        if (list == null) {
            return;
        }
        AccessibilityNodeInfo nodeInfo=list.get(list.size());
        if (nodeInfo != null) {
            if ("A、对".equals(nodeInfo.getText())) {
                boolean isClick =nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }

        }
    }

    private List<AccessibilityNodeInfo> findByText(AccessibilityNodeInfo rootnodeInfo) {
        for (String name : filter) {
            List<AccessibilityNodeInfo> list = rootnodeInfo.findAccessibilityNodeInfosByText(name);
            if (list != null && list.isEmpty()) {
                return list;
            }else
                Toast.makeText(this,"失败！",Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    @Override
    public void onInterrupt() {

    }
}
