package w.test_033;

class Figure {
    String name;

    public Figure(String name) {
        this.name = name;
    }
}
