package w.test_033;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class gettext {

    private Context context;


    public gettext(Context context) {
        // TODO Auto-generated constructor stub
        this.context = context;
    }

    public List<String> getquestionMap()  {
        List<String> list=new ArrayList<String>();
        getsqldatabase getsql = new getsqldatabase(context);
        SQLiteDatabase database = getsql.opensqlDatabase();//获取SQLiteDatabase对象
        Cursor cursor = database.rawQuery("select * from figure", null);//利用rawQuery方法查库 前面一个参数是sql语句，后面的是条件
        int colums = cursor.getColumnCount();//获取列数（该行有多少数据）
        while (cursor.moveToNext()) {//指向查询结果第一个位置
            String name = cursor.getString(cursor.getColumnIndex("name"));
            Log.i("infor",name);
            list.add(name);
            /*for (int i = 0; i < colums; i++) {
                String columname = cursor.getColumnName(i);//获取每列的列名
                String columvalue = cursor.getString(cursor.getColumnIndex(columname));//获取每列的值
                if (columvalue == null) {
                    columvalue = "";
                }
                Log.i("infor",name);
            }*/
        }
        if (database != null) {
            database.close();
        }
        return list;
    }
}