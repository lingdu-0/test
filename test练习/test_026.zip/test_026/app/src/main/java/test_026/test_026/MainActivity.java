package test_026.test_026;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    static final String db_name="test";//数据库名称
    static final String tb_name="table1";//数据表名称
    static final int max=8;//程序记录的通讯数据项上限
    static final String[] FROM = new String[] {"name","phone","email"};
    String name,phone,email;
    SQLiteDatabase db;//数据库对象
    Cursor cur;//存放查询结果的Cursor对象
    SimpleCursorAdapter adapter;
    EditText etName,etPhone,etEmail;//用于输入姓名，电话，Email的字段
    Button btInsert,btUpdate,btDelete;//新增，更新，删除按钮
    ListView lv;
    TextView txv;
    int abc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取界面上的组件
        etName = (EditText)findViewById(R.id.etName);
        etPhone =(EditText)findViewById(R.id.etPhone);
        etEmail =(EditText)findViewById(R.id.etEmail);
        btInsert =(Button)findViewById(R.id.btlnsert);
        btUpdate=(Button)findViewById(R.id.btUpdate);
        btDelete =(Button)findViewById(R.id.btDelete);
        txv = (TextView)findViewById(R.id.txv);
        //打开或创建数据库
        db = openOrCreateDatabase(db_name, Context.MODE_PRIVATE,null);
        //创建数据表
        String createTable ="CREATE TABLE IF NOT EXISTS "+tb_name+//数据表名称
                            "(_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"+//索引字段
                             "name VARCHAR(20),"+         //姓名字段
                             "phone VARCHAR(20),"+           //电话字段
                             "email VARCHAR(20))";           //邮箱字段
        db.execSQL(createTable);//创建数据表
        cur=db.rawQuery("SELECT * FROM "+tb_name,null);//查询tb_name数据表中的所有数据
        if (cur.getCount() == 0) {//若无数据则立即新增2项数据
            // 调用自定义的addData（）方法写入2组数据
            addData("小明","123456","123@qq.com");
            addData("小华","789456","456@qq.com");
            cur=db.rawQuery("SELECT * FROM "+tb_name,null);//重新查询
        }
        //创建Adapter对象
        adapter =new SimpleCursorAdapter(MainActivity.this,R.layout.item,cur,//自定义的layout和cursor对象
                FROM,//字段名数组
                new int[]{R.id.name,R.id.phone,R.id.email},0);//Text View资源ID数组
        lv =(ListView) findViewById(R.id.lv);
        lv.setAdapter(adapter);//设置Adapter
        lv.setOnItemClickListener(this);//设置单击事件的监听器
        requery();//调用自定义方法重新查询和设置按钮状态
    }

    private void requery() {//重新查询的自定义方法
       cur =db.rawQuery("SELECT * FROM "+tb_name,null);
        adapter.changeCursor(cur);//更改Adapter的cursor
        if (cur.getCount()>=max)//已达上限，停用新增按钮
            btInsert.setEnabled(false);
        else
            btInsert.setEnabled(true);
        btUpdate.setEnabled(false);//停用更新按钮，待用户选择选项后再启用
        btDelete.setEnabled(false);//停用删除按钮，待用户选择选项后再启用
    }
    private void addData(String name,String phone,String email) {
        ContentValues cv =new ContentValues(3);//创建包含3个数据项的对象
        cv.put("name",name);
        cv.put("phone",phone);
        cv.put("email",email);
        db.insert(tb_name,null,cv);//将数据加到数据表
        cur=db.rawQuery("SELECT * FROM "+tb_name,null);//重新查询
    }

    public void onlnsertUpdate(View v) {
        String nameStr=etName.getText().toString().trim();
        String phoneStr=etPhone.getText().toString().trim();
        String emailStr=etEmail.getText().toString().trim();
        if (nameStr.length()==0||phoneStr.length()==0||emailStr.length()==0) return;
        if (v.getId()==R.id.btUpdate) {//单击更新按钮
            update(nameStr, phoneStr, emailStr, cur.getInt(0));//获取_id值，更新，含此_id的记录

        }else //单击新增按钮
            addData(nameStr,phoneStr,emailStr);
        requery();//更新cursor内容
    }

    public void onDelete(View v) {
        db.delete(tb_name,"_id="+cur.getInt(0),null);
        requery();//更新cursor内容
    }
    private void update(String name, String  phone ,String email,int id) {
        ContentValues cv = new ContentValues(3);//创建包含3个数据项的对象
        cv.put("name",name);
        cv.put("phone",phone);
        cv.put("email",email);
        db.update(tb_name,cv,"_id="+id,null);//更新_id所指的记录
        // db.update(tb_name,cv,"_id= ? ",new String[]{String.valueOf(cur.getInt(0))});//更新_id所指的记录
        requery();//更新cursor内容
    }

    public void call(View v) {//打电话
        String url="tel:"+cur.getString(cur.getColumnIndex(FROM[1]));
        Intent it =new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(it);
    }

    public void mail(View v) {//发送电子邮件
        String url ="mailto:"+cur.getString(cur.getColumnIndex(FROM[2]));
        Intent it =new Intent(Intent.ACTION_SENDTO,Uri.parse(url));
        startActivity(it);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        cur.moveToPosition(position);//移动cursor至用户选取选项
        //读取姓名，电话，Email数据并显示
        etName.setText(cur.getString(cur.getColumnIndex(FROM[0])));
        etPhone.setText(cur.getString(cur.getColumnIndex(FROM[1])));
        etEmail.setText(cur.getString(cur.getColumnIndex(FROM[2])));
        btUpdate.setEnabled(true);//启用更新按钮
        btDelete.setEnabled(true);//启用删除按钮
    }
}
