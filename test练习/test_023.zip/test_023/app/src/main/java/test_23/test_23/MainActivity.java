package test_23.test_23;

import android.content.SharedPreferences;
import android.support.v4.app.NotificationCompatExtras;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    WebView wv;
    ProgressBar pb;
    EditText keyText;
    String keyword;
    String baseURL="https://www.baidu.com/s?wd=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wv = (WebView) findViewById(R.id.webview);//获取WebView组件
        pb = (ProgressBar)findViewById(R.id.pb);
        keyText = (EditText)findViewById(R.id.editText);

        wv.getSettings().setBuiltInZoomControls(true);//启用缩放功能
        wv.getSettings().setJavaScriptEnabled(true);//启用js
        wv.setWebViewClient(new WebViewClient());//创建一个WebViewClient对象
        wv.setWebChromeClient(new WebChromeClient(){
            public void onProgressChanged(WebView view,int progress){
                pb.setProgress(progress);//设置进度
                pb.setVisibility(progress<100? View.VISIBLE:View.GONE);//依进度来让进度条显示或消失
            }
        });
       // wv.loadUrl("https://www.jd.com");//链接到京东网站
    }
    public void search(View v) {
        keyword = keyText.getText().toString().replaceAll("\\s+","+");
                                        //将字符串中的单一或连续空白置换成“ + ”
        wv.loadUrl(baseURL+keyword);
    }
    protected void  onPause() {
        super.onPause();
        SharedPreferences.Editor editor =       //获取编辑器对象
                getPreferences(MODE_PRIVATE).edit();
        editor.putString("关键字",keyword);//存储当前的搜索参数
        editor.commit();
    }
    protected void onResume() {
        super.onResume();
        SharedPreferences myPref = getPreferences(MODE_PRIVATE);//获取首选项对象
        keyword =myPref.getString("关键字","江西");
                                            //读取存储的字符串项，若字符串不存在，则返回默认值“江西”
        if (wv.getUrl()==null)
            keyText.setHint(keyword);
            wv.loadUrl(baseURL+keyword);
    }
    public void onBackPressed() {
        if (wv.canGoBack()){//如果webview有上一页
            wv.goBack();//回到上一页
            return;
        }
        super.onBackPressed();//调用父类的同名方法以执行默认操作（结束程序）
    }
}
