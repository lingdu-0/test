package test_020.test_020;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View v) {
        Intent it = new Intent();
        switch (v.getId()){
            case R.id.buttonEmail:
                it.setData(Uri.parse("mailto:service@flag.com.tw"));    //设置数据
                it.putExtra(Intent.EXTRA_CC, new String[]{"kk@flag.tw"});
                it.putExtra(Intent.EXTRA_SUBJECT, "资料已收到");
                it.putExtra(Intent.EXTRA_TEXT, "您好！,\n已收到,谢谢！");
                break;
            case R.id.buttonSms:
                it.setData(Uri.parse("sms:123456?body=您好！"));
                break;
            case R.id.buttonWeb:
                it.setData(Uri.parse("http://www.baidu.com/?from=wap"));
                break;
            case R.id.buttonGps:
                it.setData(Uri.parse("geo:39.896068,116.151147"));
                break;
            case R.id.buttonWebSearch:
                it.setAction(Intent.ACTION_WEB_SEARCH);
                it.putExtra(SearchManager.QUERY,"新浪网站");
                break;
            case R.id.button1:
                it.setAction(Intent.ACTION_SEARCH);
                it.putExtra(SearchManager.QUERY,"颐和园");
                break;
        }
        startActivity(it);                      //启动适合Intent的Activity
    }
}
